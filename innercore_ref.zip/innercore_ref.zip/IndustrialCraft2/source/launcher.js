ConfigureMultiplayer({
	isClientOnly: false
});

Launch();